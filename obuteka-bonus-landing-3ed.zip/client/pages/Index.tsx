import { Header } from "@/components/Header";
import { PhoneMockup } from "@/components/PhoneMockup";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselPrevious,
  CarouselNext,
} from "@/components/ui/carousel";
import { Download, Heart, Zap, Smartphone, Package, Sparkles } from "lucide-react";
import { useState } from "react";

export default function Index() {
  const [appScreenshots] = useState([
    "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F899d4056df9b4e0182cc28d9c7cbca4d?format=webp&width=400&height=600",
    "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2Fe73bd2b5f2274af2a76fed6ee58818b0?format=webp&width=400&height=600",
    "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F8b04324baad84abeb4be9af6cbe46090?format=webp&width=400&height=600",
  ]);

  const [phone, setPhone] = useState("");
  const [smsCode, setSmsCode] = useState("");

  const faqItems = [
    {
      question: "Когда начисляются бонусы?",
      answer:
        "1000 бонусов начисляются после установки приложения ОБУТЕКА и авторизации по номеру телефона. Акция действует до 5 мая 2026 года.",
    },
    {
      question: "Можно ли получить бонусы без приложения?",
      answer:
        "Нет, бонусы по этой акции начисляются только при авторизации в мобильном приложении.",
    },
    {
      question: "На какие товары действуют бонусы?",
      answer: "Бонусы можно использовать при покупке обуви и сумок.",
    },
    {
      question: "Сколько можно оплатить бонусами?",
      answer: "Бонусами можно оплатить до 30% стоимости покупки.",
    },
    {
      question: "Сколько раз можно получить 1000 бонусов?",
      answer:
        "1000 бонусов по акции начисляются один раз на один номер телефона.",
    },
    {
      question: "Будут ли ещё бонусы в приложении?",
      answer:
        "Да, мы периодически запускаем бонусные акции и специальные предложения для пользователей приложения.",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-white to-secondary/30 py-12 sm:py-20">
        <div className="container mx-auto px-4 sm:px-6">

          {/* Mobile Version */}
          <div className="md:hidden flex flex-col gap-8">
            {/* Mobile Text Content */}
            <div className="space-y-6">
              <div className="space-y-4">
                <h1 className="text-3xl sm:text-4xl font-extrabold text-foreground leading-tight">
                  1000 бонусов пользователям приложения
                </h1>
                <p className="text-base sm:text-lg text-muted-foreground leading-relaxed">
                  Скачайте приложение ОБУТЕКА, авторизуйтесь по номеру телефона
                  и получите бонусы на покупки
                </p>
              </div>

              {/* Buttons */}
              <div className="flex flex-col gap-4">
                <Button
                  className="!rounded-full h-12 text-base font-bold w-full"
                  size="lg"
                  onClick={() => {
                    const element = document.getElementById("download-app");
                    if (element) {
                      element.scrollIntoView({ behavior: "smooth" });
                    }
                  }}
                >
                  <Download className="w-5 h-5" />
                  Скачать приложение
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                и получить бонусы
              </p>
            </div>

            {/* Mobile Phone Mockup */}
            <div className="flex justify-center items-center relative">
              <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-primary/10 rounded-3xl blur-2xl"></div>
              <div className="relative">
                <PhoneMockup
                  imageSrc={appScreenshots[0]}
                  alt="App screenshot"
                  badges={[
                    {
                      label: "1000\nбонусов",
                      position: "top-right",
                      color: "primary",
                    },
                  ]}
                />
              </div>
            </div>
          </div>

          {/* Desktop Grid */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start">
            {/* Right Content - Text (Order 1 on Desktop, Sticky) */}
            <div className="md:order-1 md:sticky md:top-24 space-y-6 sm:space-y-8 max-w-xl">
              <div className="space-y-4">
                <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-foreground leading-tight">
                  1000 бонусов пользователям приложения
                </h1>
                <p className="text-lg sm:text-xl text-muted-foreground leading-relaxed">
                  Скачайте приложение ОБУТЕКА, авторизуйтесь по номеру телефона
                  и получите бонусы на покупки
                </p>
              </div>

              {/* Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Button
                  className="!rounded-full h-12 sm:h-14 text-base sm:text-lg font-bold"
                  size="lg"
                  onClick={() => {
                    const element = document.getElementById("download-app");
                    if (element) {
                      element.scrollIntoView({ behavior: "smooth" });
                    }
                  }}
                >
                  <Download className="w-5 h-5" />
                  Скачать приложение
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                и получить бонусы
              </p>
            </div>

            {/* Left - App Screenshots in Phone Mockup with Badges (Order 2 on Desktop) */}
            <div className="md:order-2 flex justify-center items-center relative h-96">
              <div className="absolute inset-0 bg-gradient-to-r from-accent/20 to-primary/10 rounded-3xl blur-2xl"></div>
              <div className="relative">
                <PhoneMockup
                  imageSrc={appScreenshots[0]}
                  alt="App screenshot"
                  badges={[
                    {
                      label: "1000\nбонусов",
                      position: "top-right",
                      color: "primary",
                    },
                  ]}
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How to Get Bonuses Section */}
      <section id="how-to-get" className="py-16 sm:py-24 bg-white">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12 sm:mb-16 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground">
              Как получить и использовать бонусы
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Всего три шага — и бонусы ваши
            </p>
          </div>

          {/* Full-screen Carousel for all devices */}
          <div className="relative w-full overflow-hidden">
            <Carousel className="w-full overflow-hidden">
              <CarouselContent>
                {[
                  {
                    image: "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F66a60cdb63f14a419359bb34cd80fa7b?format=webp&width=800&height=1200",
                  },
                  {
                    image: "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2Ff1a8aa9f6107478ab65e1eea0d7055b1?format=webp&width=800&height=1200",
                  },
                  {
                    image: "https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F3ce3aaa4039744bbb06d3a409a27c806?format=webp&width=800&height=1200",
                  },
                ].map((item, index) => (
                  <CarouselItem key={index} className="basis-full md:basis-1/3 pl-4">
                    <div className="flex items-center justify-center w-full h-full rounded-3xl overflow-hidden border border-border">
                      <img src={item.image} alt={`Шаг ${index + 1}`} className="h-auto object-contain" />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="absolute left-0 sm:left-2 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 bg-white border border-border hover:bg-accent/10 rounded-full" />
              <CarouselNext className="absolute right-0 sm:right-2 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 bg-white border border-border hover:bg-accent/10 rounded-full" />
            </Carousel>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 sm:py-24 bg-secondary/50">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12 sm:mb-16 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground">
              Покупки выгоднее в приложении
            </h2>
          </div>

          {/* Benefits Grid - Desktop */}
          <div className="hidden md:grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
            {[
              {
                title: "Бонусы для вас",
                description:
                  "Получайте бонусы в приложении ОБУТЕКА и оплачивайте ими до 30% покупок.",
                icon: Zap,
              },
              {
                title: "Не упустите выгоду",
                description:
                  "Следите за акциями, новинками и специальными предложениями в приложении.",
                icon: Heart,
              },
              {
                title: "Быстро и удобно",
                description:
                  "Оформляйте заказы, отслеживайте покупки и выбирайте обувь в пару кликов.",
                icon: Package,
              },
              {
                title: "Всегда под рукой",
                description:
                  "Ваши бонусы, заказы и избранные модели — в одном приложении.",
                icon: Smartphone,
              },
            ].map((benefit, index) => {
              const Icon = benefit.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-3xl p-8 sm:p-10 border border-border hover:shadow-lg transition-shadow duration-300"
                >
                  <div className="flex items-start gap-4 sm:gap-6">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center w-12 h-12 sm:w-16 sm:h-16 rounded-full bg-accent/20">
                        <Icon className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
                      </div>
                    </div>
                    <div className="flex-1 space-y-3">
                      <h3 className="text-xl sm:text-2xl font-bold text-foreground">
                        {benefit.title}
                      </h3>
                      <p className="text-muted-foreground text-base leading-relaxed">
                        {benefit.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Benefits Carousel - Mobile */}
          <div className="md:hidden overflow-hidden">
            <Carousel className="w-full relative rounded-3xl overflow-hidden">
              <CarouselContent>
                {[
                  {
                    title: "Бонусы для вас",
                    description:
                      "Получайте бонусы в приложении ОБУТЕКА и оплачивайте ими до 30% покупок.",
                    icon: Zap,
                  },
                  {
                    title: "Не упустите выгоду",
                    description:
                      "Следите за акциями, новинками и специальными предложениями в приложении.",
                    icon: Heart,
                  },
                  {
                    title: "Быстро и удобно",
                    description:
                      "Оформляйте заказы, отслеживайте покупки и выбирайте обувь в пару кликов.",
                    icon: Package,
                  },
                  {
                    title: "Всегда под рукой",
                    description:
                      "Ваши бонусы, заказы и избранные модели — в одном приложении.",
                    icon: Smartphone,
                  },
                ].map((benefit, index) => {
                  const Icon = benefit.icon;
                  return (
                    <CarouselItem key={index} className="basis-full pl-4 pr-2">
                      <div className="bg-white rounded-2xl p-6 border border-border hover:shadow-lg transition-shadow duration-300 h-full flex flex-col">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0">
                            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-accent/20">
                              <Icon className="w-6 h-6 text-primary" />
                            </div>
                          </div>
                          <div className="flex-1 space-y-3">
                            <h3 className="text-lg font-bold text-foreground">
                              {benefit.title}
                            </h3>
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {benefit.description}
                            </p>
                          </div>
                        </div>
                      </div>
                    </CarouselItem>
                  );
                })}
              </CarouselContent>
              <CarouselPrevious className="absolute left-0 sm:left-2 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 bg-white border border-border hover:bg-accent/10 rounded-full" />
              <CarouselNext className="absolute right-0 sm:right-2 top-1/2 -translate-y-1/2 h-10 w-10 sm:h-12 sm:w-12 bg-white border border-border hover:bg-accent/10 rounded-full" />
            </Carousel>
            {/* Pagination Dots */}
            <div className="flex justify-center gap-2 mt-6">
              {[0, 1, 2, 3].map((_, index) => (
                <div key={index} className="h-2 w-2 rounded-full bg-primary/30 hover:bg-primary/60 transition-colors cursor-pointer" />
              ))}
            </div>
            {/* Swipe Hint */}
            <p className="text-center text-xl text-muted-foreground mt-4">
              ← →
            </p>
          </div>
        </div>
      </section>

      {/* Download App Section */}
      <section id="download-app" className="py-8 sm:py-12 bg-white mx-4 sm:mx-6 rounded-3xl">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Left - QR and Stores */}
            <div className="space-y-8 md:order-2">
              <div className="space-y-4">
                <h2 className="text-3xl sm:text-4xl font-extrabold text-foreground">
                  Скачивайте приложение, и забирайте бонусы
                </h2>
              </div>

              {/* QR Code Section */}
              <div className="space-y-4">
                <div className="w-40 h-40 sm:w-48 sm:h-48 rounded-2xl flex items-center justify-center border-2 border-border overflow-hidden bg-white">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F121309e1467c48e58fc829277c8b8a3a?format=webp&width=800&height=1200"
                    alt="QR-код"
                    className="w-full h-full object-contain"
                  />
                </div>
                <p className="text-sm sm:text-base text-muted-foreground">
                  Наведите камеру, чтобы скачать приложение
                </p>
              </div>

              {/* Store Buttons */}
              <div className="grid grid-cols-1 gap-4 w-max">
                <a href="https://play.google.com/store/apps/details?id=ru.obuteka.app&hl=ru" target="_blank" rel="noopener noreferrer" className="h-12 sm:h-14 rounded-2xl overflow-hidden hover:opacity-90 transition-opacity flex items-center justify-center">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F0cb22f2c67e5429497ba6e7e240702c6?format=webp&width=800&height=1200"
                    alt="Скачать через Google Play"
                    className="h-full object-contain"
                  />
                </a>
                <a href="https://apps.apple.com/cy/app/обутека-обувь-аксессуары/id6759326437" target="_blank" rel="noopener noreferrer" className="h-16 sm:h-20 rounded-2xl overflow-hidden hover:opacity-90 transition-opacity flex items-center justify-center">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2Fdf49853594da4a11a21941407a4c2681?format=webp&width=800&height=1200"
                    alt="Скачать через App Store"
                    className="w-full h-full object-contain"
                  />
                </a>
              </div>
            </div>

            {/* Right - App Screenshot in Phone Mockup */}
            <div className="hidden md:flex justify-center items-center relative h-96 md:order-1">
              <div className="absolute inset-0 bg-gradient-to-l from-accent/20 to-primary/10 rounded-3xl blur-2xl"></div>
              <div className="relative">
                <PhoneMockup
                  imageSrc={appScreenshots[0]}
                  alt="App screenshot"
                />
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="py-16 sm:py-24 bg-secondary/30">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="text-center mb-12 sm:mb-16 space-y-4">
            <h2 className="text-3xl sm:text-5xl font-extrabold text-foreground">
              Часто задаваемые вопросы
            </h2>
          </div>

          {/* FAQ Accordion */}
          <div className="max-w-3xl mx-auto">
            <Accordion type="single" collapsible className="space-y-4">
              {faqItems.map((item, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-white rounded-2xl border border-border px-6 py-4"
                >
                  <AccordionTrigger className="text-lg sm:text-xl font-bold text-foreground hover:text-primary">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-base text-muted-foreground leading-relaxed mt-4">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </section>

      {/* Footer Section */}
      <footer className="bg-muted/50 border-t border-border py-12 sm:py-16">
        <div className="container mx-auto px-4 sm:px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            {/* Left - Logo and Text */}
            <div className="space-y-4">
              <div>
                <img 
                  src="https://static.insales-cdn.com/files/1/3761/95596209/original/Artboard_1ssss.svg"
                  alt="ОБУТЕКА"
                  className="h-12 sm:h-16 w-auto"
                />
              </div>

              {/* Legal Text */}
              <div className="space-y-3 pt-4 text-xs sm:text-sm text-muted-foreground leading-relaxed">
                <p>
                  Акция действует в мобильном приложении ОБУТЕКА до 5 мая 2026 года. 1000 бонусов
                  начисляются после установки приложения и авторизации по номеру
                  телефона.
                </p>
                <p>
                  Начисление производится один раз на один номер телефона.
                  Бонусами можно оплатить до 30% стоимости покупки. Бонусы
                  действуют только на обувь и сумки.
                </p>
                <p>
                  Срок действия бонусов ограничен. Компания оставляет за собой
                  право изменить условия акции без предварительного уведомления.
                  Не является публичной офертой.
                </p>
              </div>
            </div>

            {/* Right - QR Code */}
            <div className="flex items-start justify-start md:justify-end">
              <div className="flex flex-col sm:flex-row gap-4 items-center md:items-start">
                <div className="w-32 h-32 sm:w-40 sm:h-40 bg-white rounded-lg flex items-center justify-center border-2 border-border shadow-sm flex-shrink-0 overflow-hidden">
                  <img
                    src="https://cdn.builder.io/api/v1/image/assets%2F8d16e0239de04e4d8b3babc3294044cb%2F121309e1467c48e58fc829277c8b8a3a?format=webp&width=800&height=1200"
                    alt="QR код для скачивания приложения ОБУТЕКА"
                    className="w-full h-full object-contain"
                  />
                </div>
                <div className="text-center sm:text-left mt-6">
                  <p className="text-sm sm:text-base font-semibold text-foreground leading-tight">
                    Скачайте<br />приложение<br />ОБУТЕКА
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
