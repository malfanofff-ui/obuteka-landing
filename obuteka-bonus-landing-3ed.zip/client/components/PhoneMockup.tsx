interface Badge {
  label: string;
  color?: "primary" | "secondary";
  position: "top-left" | "top-right" | "bottom-left" | "bottom-right";
}

interface PhoneMockupProps {
  imageSrc: string;
  alt: string;
  badges?: Badge[];
  compact?: boolean;
}

export function PhoneMockup({ imageSrc, alt, badges = [], compact = false }: PhoneMockupProps) {
  const getPositionClasses = (position: string) => {
    switch (position) {
      case "top-left":
        return "top-0 left-0 -translate-x-1/2 -translate-y-1/2";
      case "top-right":
        return "top-0 right-0 translate-x-1/2 -translate-y-1/2";
      case "bottom-left":
        return "bottom-0 left-0 -translate-x-1/2 translate-y-1/2";
      case "bottom-right":
        return "bottom-0 right-0 translate-x-1/2 translate-y-1/2";
      default:
        return "";
    }
  };

  const getBgColor = (color?: string) => {
    switch (color) {
      case "primary":
        return "bg-primary";
      case "secondary":
        return "bg-secondary/20 text-primary";
      default:
        return "bg-primary";
    }
  };

  return (
    <div className="relative inline-block">
      {/* Phone frame outer shadow */}
      <div className="absolute -inset-1 bg-gradient-to-br from-gray-400 to-gray-600 rounded-[3rem] opacity-15 blur-lg"></div>

      {/* Main phone body */}
      <div className={`relative ${compact ? 'w-32 h-64 sm:w-40 sm:h-80' : 'w-48 h-96 sm:w-56 sm:h-[28rem]'} bg-black rounded-[2.5rem] p-1 shadow-2xl`}>
        {/* Notch */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-28 h-3 bg-black rounded-b-3xl z-10"></div>

        {/* Screen border/bezel */}
        <div className="relative w-full h-full bg-black rounded-[2.2rem] overflow-hidden">
          {/* Screen content */}
          <img
            src={imageSrc}
            alt={alt}
            className="w-full h-full object-cover"
          />
        </div>

      </div>

      {/* Discount Badges */}
      {badges.map((badge, index) => (
        <div
          key={index}
          className={`absolute ${getPositionClasses(badge.position)} z-20 transform`}
        >
          <div
            className={`${getBgColor(badge.color)} text-white rounded-full w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center font-bold text-xs sm:text-sm shadow-lg border-4 border-white text-center leading-tight`}
          >
            <span className="whitespace-normal">{badge.label}</span>
          </div>
        </div>
      ))}
    </div>
  );
}
