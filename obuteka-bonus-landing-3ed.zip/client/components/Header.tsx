import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setMobileMenuOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white border-b border-border">
      <div className="container mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <a href="https://obuteka.ru/" target="_blank" rel="noopener noreferrer">
              <img
                src="https://static.insales-cdn.com/files/1/3761/95596209/original/Artboard_1ssss.svg"
                alt="ОБУТЕКА"
                className="h-12 sm:h-16 w-auto"
              />
            </a>
          </div>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center gap-12">
            <button
              onClick={() => scrollToSection("how-to-get")}
              className="text-sm font-medium text-foreground hover:text-primary transition-colors border-b-2 border-foreground pb-1 hover:border-primary"
            >
              Как получить скидку
            </button>
            <button
              onClick={() => scrollToSection("faq")}
              className="text-sm font-medium text-foreground hover:text-primary transition-colors border-b-2 border-foreground pb-1 hover:border-primary"
            >
              Частые вопросы
            </button>
          </nav>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden pb-4 space-y-2">
            <button
              onClick={() => scrollToSection("how-to-get")}
              className="block w-full text-left px-4 py-3 text-sm font-medium text-foreground border-b-2 border-foreground hover:border-primary hover:text-primary transition-colors"
            >
              Как получить скидку
            </button>
            <button
              onClick={() => scrollToSection("faq")}
              className="block w-full text-left px-4 py-3 text-sm font-medium text-foreground border-b-2 border-foreground hover:border-primary hover:text-primary transition-colors"
            >
              Частые вопросы
            </button>
          </nav>
        )}
      </div>
    </header>
  );
}
